﻿namespace ByteCobra.Logging.Settings
{
    public class TagSettings
    {
        /// <summary>
        /// The prefix for fatal logs.
        /// </summary>
        public string FatalTag { get; set; } = "[FATAL]";

        /// <summary>
        /// The prefix for error logs.
        /// </summary>
        public string ErrorTag { get; set; } = "[ERROR]";

        /// <summary>
        /// The prefix for warning logs.
        /// </summary>
        public string WarningTag { get; set; } = "[WARNING]";

        /// <summary>
        /// The prefix for info logs.
        /// </summary>
        public string InfoTag { get; set; } = "[INFO]";

        /// <summary>
        /// The prefix for debug logs.
        /// </summary>
        public string DebugTag { get; set; } = "[DEBUG]";

        /// <summary>
        /// The prefix for assertion logs.
        /// </summary>
        public string AssertTag { get; set; } = "[ASSERT]";
    }
}