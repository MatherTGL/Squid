﻿namespace ByteCobra.Logging.Settings
{
    /// <summary>
    /// Provides settings for configuring log message colors.
    /// </summary>
    public class ColorSettings
    {
        /// <summary>
        /// Gets or sets the color for formatting debug log messages.
        /// </summary>
        public string DebugLogColor { get; set; } = "white";

        /// <summary>
        /// Gets or sets the color for formatting informational log messages.
        /// </summary>
        public string InfoLogColor { get; set; } = "green";

        /// <summary>
        /// Gets or sets the color for formatting warning log messages.
        /// </summary>
        public string WarningLogColor { get; set; } = "yellow";

        /// <summary>
        /// Gets or sets the color for formatting assert log messages.
        /// </summary>
        public string AssertLogColor { get; set; } = "red";

        /// <summary>
        /// Gets or sets the color for formatting error log messages.
        /// </summary>
        public string ErrorLogColor { get; set; } = "red";

        /// <summary>
        /// Gets or sets the color for formatting fatal log messages.
        /// </summary>
        public string FatalLogColor { get; set; } = "red";
    }
}