﻿using ByteCobra.Logging.Logs;
using System;
using System.Text;

namespace ByteCobra.Logging.Settings
{
    /// <summary>
    /// Provides settings for formatting log messages.
    /// </summary>
    public class FormatSettings
    {
        /// <summary>
        /// Gets or sets the default log message format delegate.
        /// </summary>
        /// <remarks>
        /// This delegate defines the default log message format. It takes a <see cref="BaseLog"/>
        /// instance as a parameter and returns the formatted log message. The format may vary based
        /// on whether the application is running in the editor or not.
        /// </remarks>
        public static Func<BaseLog, string> DefaultFormat { get; set; } = log =>
        {
            StringBuilder sb = new StringBuilder();

            string? msg = log.OriginalMessage?.ToString();

            if (LogSettings.IsEditor)
            {
                sb.Append("<color=")
                  .Append(log.Color)
                  .Append('>');
            }

            if (!LogSettings.IsEditor)
            {
                sb.Append('[')
                  .Append(log.Time.ToString(LogSettings.TimeFormat))
                  .Append("] ");
            }

            sb.Append(log.Tag)
              .Append(' ')
              .Append(log.FileName)
              .Append('[')
              .Append(log.Line)
              .Append(']');

            if (LogSettings.IsEditor)
            {
                sb.Append("</color>");
            }

            if (msg != null)
            {
                sb.Append(": ").Append(msg);
            }

            return sb.ToString();
        };

        /// <summary>
        /// Gets or sets the log message format delegate for debug logs.
        /// </summary>
        public virtual Func<DebugLog, string> DebugFormat { get; set; } = DefaultFormat;

        /// <summary>
        /// Gets or sets the log message format delegate for informational logs.
        /// </summary>
        public virtual Func<InfoLog, string> InfoFormat { get; set; } = DefaultFormat;

        /// <summary>
        /// Gets or sets the log message format delegate for warning logs.
        /// </summary>
        public virtual Func<WarningLog, string> WarningFormat { get; set; } = DefaultFormat;

        /// <summary>
        /// Gets or sets the log message format delegate for assert logs.
        /// </summary>
        public virtual Func<AssertLog, string> AssertFormat { get; set; } = DefaultFormat;

        /// <summary>
        /// Gets or sets the log message format delegate for error logs.
        /// </summary>
        public virtual Func<ErrorLog, string> ErrorFormat { get; set; } = DefaultFormat;

        /// <summary>
        /// Gets or sets the log message format delegate for fatal logs.
        /// </summary>
        public virtual Func<FatalLog, string> FatalFormat { get; set; } = DefaultFormat;

        private static string GetAnsiColorCode(string colorName)
        {
            return colorName.ToLower() switch
            {
                "black" => "\u001b[30m",
                "red" => "\u001b[91m",
                "green" => "\u001b[92m",
                "yellow" => "\u001b[93m",
                "blue" => "\u001b[34m",
                "magenta" => "\u001b[35m",
                "cyan" => "\u001b[36m",
                "white" => "\u001b[97m",
                _ => "",  // Default to no color.
            };
        }
    }
}