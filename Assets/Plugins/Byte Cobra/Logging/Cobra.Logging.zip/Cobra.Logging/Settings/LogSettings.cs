﻿using System;
using System.Collections.Generic;

namespace ByteCobra.Logging.Settings
{
    /// <summary>
    /// Provides settings for configuring the behavior of the logging system.
    /// </summary>
    public static class LogSettings
    {
        public static bool IsEditor = true;

        /// <summary>
        /// The minimum log level.
        /// </summary>
        public static LogLevel MinimumLogLevel { get; set; } = LogLevel.Debug;

        /// <summary>
        /// Gets or sets a value indicating whether to capture stack traces for logs.
        /// </summary>
        public static bool CaptureStackTrace { get; set; } = true;

        /// <summary>
        /// Gets or sets the time format used for formatting log timestamps.
        /// </summary>
        public static string TimeFormat { get; set; } = "HH:mm:ss";

        /// <summary>
        /// Gets or sets the action to be executed when the application is quit.
        /// </summary>
        public static Action QuitAction { get; set; } = () => { };

        /// <summary>
        /// Gets or sets the serializer for serializing state information of logs.
        /// </summary>
        public static StateSerializer StateSerializer { get; set; } = new JsonStateSerializer();

        /// <summary>
        /// Gets or sets the settings for formatting log messages.
        /// </summary>
        public static FormatSettings FormatSettings { get; set; } = new FormatSettings();

        /// <summary>
        /// Gets or sets the settings for printing log messages.
        /// </summary>
        public static PrintSettings PrintSettings { get; set; } = new PrintSettings();

        /// <summary>
        /// Gets or sets the set of filters to be applied to log messages.
        /// </summary>
        public static HashSet<Filter> Filters { get; set; } = new HashSet<Filter>();

        /// <summary>
        /// Gets or sets the settings for logging to files.
        /// </summary>
        public static FileSettings FileSettings { get; set; } = new FileSettings();

        /// <summary>
        /// Gets or sets the settings for log tag formatting.
        /// </summary>
        public static TagSettings TagSettings { get; set; } = new TagSettings();

        /// <summary>
        /// Gets or sets the settings for log color formatting.
        /// </summary>
        public static ColorSettings ColorSettings { get; set; } = new ColorSettings();
    }
}