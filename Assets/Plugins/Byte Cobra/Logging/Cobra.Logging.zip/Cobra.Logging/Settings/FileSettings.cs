﻿using System.IO;

namespace ByteCobra.Logging.Settings
{
    /// <summary>
    /// Provides settings for configuring log file behavior.
    /// </summary>
    public class FileSettings
    {
        /// <summary>
        /// Gets or sets the maximum allowed file size for log files. Defaults to 100 MB.
        /// </summary>
        public long MaxFileSize { get; set; } = 1024 * 1024 * 100;

        /// <summary>
        /// Gets or sets the maximum allowed file size for the state directory. Defaults to 100 MB.
        /// </summary>
        public long MaxStateDirectorySize { get; set; } = 1024 * 1024 * 100;

        /// <summary>
        /// Gets or sets the directory where log files will be stored.
        /// </summary>
        public DirectoryInfo LogFilesDirectory
        {
            get => logFilesDirectory;
            set
            {
                logFilesDirectory = value;
                logFile = new FileInfo(Path.Combine(LogFilesDirectory.FullName, FileName));
            }
        }

        private DirectoryInfo logFilesDirectory = new DirectoryInfo("Logs");
        private FileInfo logFile = new FileInfo("Logs/States");

        /// <summary>
        /// Gets or sets the directory where object states will be serialized and stored.
        /// </summary>
        public DirectoryInfo StatesDirectory { get; set; } = new DirectoryInfo($"Logs{Path.DirectorySeparatorChar}States");

        /// <summary>
        /// Gets or sets a value indicating whether all log messages are logged to files.
        /// </summary>
        public bool SaveLogs { get; set; } = true;

        public bool SaveStates { get; set; } = true;

        /// <summary>
        /// Gets or sets the filename for all log messages.
        /// </summary>
        public string FileName { get; set; } = "Logs.txt";
    }
}