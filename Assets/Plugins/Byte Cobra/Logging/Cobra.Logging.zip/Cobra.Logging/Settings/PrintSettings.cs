﻿using System;
using UnityEngine;

namespace ByteCobra.Logging.Settings
{
    /// <summary>
    /// Provides settings for printing log messages to the console or other output.
    /// </summary>
    public class PrintSettings
    {
        private Action<string> defaultPrinter = log =>
        {
            Debug.Log(log);
        };

        public PrintSettings()
        {
            PrintDebug = defaultPrinter;
            PrintInfo = defaultPrinter;
            PrintWarning = defaultPrinter;
            PrintAssert = defaultPrinter;
            PrintError = defaultPrinter;
            PrintFatal = defaultPrinter;
        }

        public Action<string> DefaultPrinter
        {
            get => defaultPrinter;
            set
            {
                defaultPrinter = value;

                PrintDebug = defaultPrinter;
                PrintInfo = defaultPrinter;
                PrintWarning = defaultPrinter;
                PrintAssert = defaultPrinter;
                PrintError = defaultPrinter;
                PrintFatal = defaultPrinter;
            }
        }

        /// <summary>
        /// Gets or sets the log message printer delegate for debug logs.
        /// </summary>
        public virtual Action<string> PrintDebug { get; set; }

        /// <summary>
        /// Gets or sets the log message printer delegate for informational logs.
        /// </summary>
        public virtual Action<string> PrintInfo { get; set; }

        /// <summary>
        /// Gets or sets the log message printer delegate for warning logs.
        /// </summary>
        public virtual Action<string> PrintWarning { get; set; }

        /// <summary>
        /// Gets or sets the log message printer delegate for assert logs.
        /// </summary>
        public virtual Action<string> PrintAssert { get; set; }

        /// <summary>
        /// Gets or sets the log message printer delegate for error logs.
        /// </summary>
        public virtual Action<string> PrintError { get; set; }

        /// <summary>
        /// Gets or sets the log message printer delegate for fatal logs.
        /// </summary>
        public virtual Action<string> PrintFatal { get; set; }
    }
}