﻿using ByteCobra.Logging.Logs;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;

namespace ByteCobra.Logging
{
    /// <summary>
    /// Provides assertion methods for validating conditions and logging messages.
    /// </summary>
    public static class Assert
    {
        private static readonly ConcurrentDictionary<string, Delegate> expressionCache = new ConcurrentDictionary<string, Delegate>();

        /// <summary>
        /// Asserts that the specified parameter is not null.
        /// </summary>
        /// <typeparam name="T">The type of the parameter.</typeparam>
        /// <param name="parameterExpression">An expression representing the parameter to check.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? NotNull<T>(
            Expression<Func<T>> parameterExpression,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            return AssertWithExpression(parameterExpression, paramValue => paramValue != null, message, throwException, file, line, state, "was null");
        }

        /// <summary>
        /// Asserts that the specified collection is not empty.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="parameterExpression">An expression representing the collection to check.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? NotEmpty<T>(
            Expression<Func<IEnumerable<T>>> parameterExpression,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            return AssertWithExpression(parameterExpression, collection => collection != null && collection.Any(), message, throwException, file, line, state, "was empty");
        }

        /// <summary>
        /// Asserts that the specified string is not null or whitespace.
        /// </summary>
        /// <param name="parameterExpression">An expression representing the string to check.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? NotNullOrWhitespace(
            Expression<Func<string?>> parameterExpression,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            return AssertWithExpression(parameterExpression, value => !string.IsNullOrWhiteSpace(value), message, throwException, file, line, state, "was null or whitespace");
        }

        /// <summary>
        /// Asserts that the specified value is greater than the specified limit.
        /// </summary>
        /// <typeparam name="T">The type of the value and limit.</typeparam>
        /// <param name="parameterExpression">An expression representing the value to check.</param>
        /// <param name="limit">The limit to compare against.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? GreaterThan<T>(
            Expression<Func<T>> parameterExpression,
            T limit,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null) where T : IComparable
        {
            var value = parameterExpression.Compile()();
            return AssertWithExpression(parameterExpression, value => value.CompareTo(limit) > 0, message, throwException, file, line, state, $"was {value}, which is not greater than {limit}");
        }

        /// <summary>
        /// Asserts that the specified value is less than the specified limit.
        /// </summary>
        /// <typeparam name="T">The type of the value and limit.</typeparam>
        /// <param name="parameterExpression">An expression representing the value to check.</param>
        /// <param name="limit">The limit to compare against.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? LessThan<T>(
            Expression<Func<T>> parameterExpression,
            T limit,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null) where T : IComparable
        {
            var value = parameterExpression.Compile()();
            return AssertWithExpression(parameterExpression, value => value.CompareTo(limit) < 0, message, throwException, file, line, state, $"was {value}, which is not less than {limit}");
        }

        /// <summary>
        /// Asserts that the specified value is within the specified range (inclusive).
        /// </summary>
        /// <typeparam name="T">The type of the value, min, and max.</typeparam>
        /// <param name="parameterExpression">An expression representing the value to check.</param>
        /// <param name="min">The minimum value of the range.</param>
        /// <param name="max">The maximum value of the range.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? InRange<T>(
            Expression<Func<T>> parameterExpression,
            T min,
            T max,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null) where T : IComparable
        {
            return AssertWithExpression(parameterExpression, value => value.CompareTo(min) >= 0 && value.CompareTo(max) <= 0, message, throwException, file, line, state, $"was not in the range {min} to {max}");
        }

        /// <summary>
        /// Asserts that the specified collection is not null and not empty.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="parameterExpression">An expression representing the collection to check.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? NotNullOrEmpty<T>(
            Expression<Func<IEnumerable<T>>> parameterExpression,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            return AssertWithExpression(parameterExpression, collection => collection != null && collection.Any(), message, throwException, file, line, state, "was null or empty");
        }

        /// <summary>
        /// Asserts that the value of the specified parameter is equal to the expected value.
        /// </summary>
        /// <typeparam name="T">The type of the parameter and the expected value.</typeparam>
        /// <param name="parameterExpression">An expression representing the parameter to check.</param>
        /// <param name="expectedValue">The expected value to compare against the parameter's value.</param>
        /// <param name="message">An optional message to include in the log entry. If not provided, a default message indicating the expected and actual values will be used.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails. Defaults to false.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion. Returns null if the assertion passes (i.e., the values are equal).</returns>
        public static AssertLog? AreEqual<T>(
            Expression<Func<T>> parameterExpression,
            T expectedValue,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            var expressionKey = parameterExpression.ToString();
            var compiledExpression = (Func<T>)expressionCache.GetOrAdd(expressionKey, _ => parameterExpression.Compile());
            var actualValue = compiledExpression();
            var paramName = ((MemberExpression)parameterExpression.Body).Member.Name;

            if (!EqualityComparer<T>.Default.Equals(actualValue, expectedValue))
            {
                var defaultMessage = $"Expected '{paramName}' to have the value '{expectedValue}' but it was '{actualValue}'.";
                var finalMessage = message ?? defaultMessage;
                return Log.Assert(false, finalMessage, throwException, file, line, state);
            }

            return null;
        }

        /// <summary>
        /// Asserts that the specified collection contains at least one item that satisfies the provided condition.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collectionExpression">An expression representing the collection to check.</param>
        /// <param name="condition">A predicate function to test each element for a condition.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? Contains<T>(
            Expression<Func<IEnumerable<T>>> collectionExpression,
            Func<T, bool> condition,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            var expressionKey = collectionExpression.ToString();
            var compiledExpression = (Func<IEnumerable<T>>)expressionCache.GetOrAdd(expressionKey, _ => collectionExpression.Compile());
            var collection = compiledExpression();
            var paramName = ((MemberExpression)collectionExpression.Body).Member.Name;

            if (collection == null || !collection.Any(condition))
            {
                var defaultMessage = $"Expected collection '{paramName}' to contain an item matching the condition, but it does not.";
                var finalMessage = message ?? defaultMessage;
                return Log.Assert(false, finalMessage, throwException, file, line, state);
            }

            return null;
        }

        /// <summary>
        /// Asserts that the specified collection does not contain any item that satisfies the provided condition.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collectionExpression">An expression representing the collection to check.</param>
        /// <param name="condition">A predicate function to test each element for a condition.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? DoesNotContain<T>(
            Expression<Func<IEnumerable<T>>> collectionExpression,
            Func<T, bool> condition,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            var expressionKey = collectionExpression.ToString();
            var compiledExpression = (Func<IEnumerable<T>>)expressionCache.GetOrAdd(expressionKey, _ => collectionExpression.Compile());
            var collection = compiledExpression();
            var paramName = ((MemberExpression)collectionExpression.Body).Member.Name;

            if (collection != null && collection.Any(condition))
            {
                var defaultMessage = $"Expected collection '{paramName}' to not contain any item matching the condition, but it does.";
                var finalMessage = message ?? defaultMessage;
                return Log.Assert(false, finalMessage, throwException, file, line, state);
            }

            return null;
        }

        /// <summary>
        /// Asserts that the specified object implements the specified interface.
        /// </summary>
        /// <typeparam name="TInterface">The interface type that the object is expected to implement.</typeparam>
        /// <param name="objectExpression">An expression representing the object to check.</param>
        /// <param name="message">An optional message to include in the log entry.</param>
        /// <param name="throwException">A flag indicating whether to throw an exception if the assertion fails.</param>
        /// <param name="file">The file path of the caller (automatically provided).</param>
        /// <param name="line">The line number of the caller (automatically provided).</param>
        /// <param name="state">An optional state object to include in the log entry.</param>
        /// <returns>An <see cref="AssertLog"/> object representing the result of the assertion.</returns>
        public static AssertLog? Implements<TInterface>(
            Expression<Func<object>> objectExpression,
            object? message = null,
            bool throwException = true,
            [CallerFilePath] string file = "",
            [CallerLineNumber] int line = -1,
            object? state = null)
        {
            var expressionKey = objectExpression.ToString();
            var compiledExpression = (Func<object>)expressionCache.GetOrAdd(expressionKey, _ => objectExpression.Compile());
            var obj = compiledExpression();
            var paramName = ((MemberExpression)objectExpression.Body).Member.Name;

            bool implementsInterface = typeof(TInterface).IsAssignableFrom(obj.GetType());

            if (!implementsInterface)
            {
                var defaultMessage = $"Expected object '{paramName}' to implement interface '{typeof(TInterface).Name}', but it does not.";
                var finalMessage = message ?? defaultMessage;
                return Log.Assert(false, finalMessage, throwException, file, line, state);
            }

            return null;
        }

        private static AssertLog? AssertWithExpression<T>(
            Expression<Func<T>> parameterExpression,
            Func<T, bool> condition,
            object? message,
            bool throwException,
            string file,
            int line,
            object? state,
            string defaultErrorMessage)
        {
            var expressionKey = parameterExpression.ToString();
            var compiledExpression = (Func<T>)expressionCache.GetOrAdd(expressionKey, _ => parameterExpression.Compile());
            var paramValue = compiledExpression();
            var paramName = ((MemberExpression)parameterExpression.Body).Member.Name;
            string fallbackMessage = message == null ? $"{paramName} {defaultErrorMessage}" : message.ToString();

            return Log.Assert(condition(paramValue), fallbackMessage, throwException, file, line, state);
        }
    }
}