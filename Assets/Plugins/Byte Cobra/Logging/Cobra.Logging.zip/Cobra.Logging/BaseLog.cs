﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace ByteCobra.Logging
{
    /// <summary>
    /// Provides a base class for log messages.
    /// </summary>
    public abstract class BaseLog
    {
        /// <summary>
        /// The log level.
        /// </summary>
        public abstract LogLevel LogLevel { get; }

        /// <summary>
        /// Gets the original log message.
        /// </summary>
        public object? OriginalMessage { get; }

        /// <summary>
        /// Gets the formatted log message.
        /// </summary>
        public abstract string FormattedMessage { get; }

        /// <summary>
        /// Gets the color associated with the log message.
        /// </summary>
        public abstract string Color { get; }

        /// <summary>
        /// Gets the type of the log (e.g., Debug, Info, Warning).
        /// </summary>
        public abstract Type Type { get; }

        /// <summary>
        /// Gets the tag associated with the log message.
        /// </summary>
        public abstract string Tag { get; }

        /// <summary>
        /// Gets the file path of the log's source.
        /// </summary>
        public string FileName { get; }

        /// <summary>
        /// Gets information about the log's source file.
        /// </summary>
        public FileInfo FileInfo => new FileInfo(FileName);

        /// <summary>
        /// Gets the line number of the log's source.
        /// </summary>
        public int Line { get; }

        /// <summary>
        /// Gets the stack trace associated with the log.
        /// </summary>
        public StackTrace? StackTrace { get; }

        /// <summary>
        /// Gets the state of the object associated with the log message.
        /// </summary>
        public ObjectState? State { get; }

        /// <summary>
        /// Gets the timestamp when the log was created.
        /// </summary>
        public DateTime Time { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseLog"/> class.
        /// </summary>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="filePath">The file path of the log's source.</param>
        /// <param name="line">The line number of the log's source.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The state of the object associated with the log message.</param>
        public BaseLog(StackTrace? stackTrace, string filePath, int line, object? message, ObjectState? objectState)
        {
            FileName = GetFileName(filePath);
            Line = line;
            OriginalMessage = message;
            State = objectState;
            StackTrace = stackTrace;
            Time = DateTime.Now;

            if (objectState != null)
                objectState.Message = OriginalMessage?.ToString();
        }

        private static string GetFileName(string path)
        {
            string fileName = Path.GetFileName(path);

            try
            {
                // Check if the fileName still contains directory separators
                if (fileName.Contains('/') || fileName.Contains('\\'))
                {
                    int lastIndex = fileName.LastIndexOfAny(new char[] { '\\', '/' });
                    if (lastIndex >= 0)
                    {
                        // Extract the substring after the last index of a separator
                        return fileName.Substring(lastIndex + 1);
                    }
                }

                return fileName ?? string.Empty;
            }
            catch
            {
                // Return the original path if an error occurs
                return fileName ?? string.Empty;
            }
        }
    }
}