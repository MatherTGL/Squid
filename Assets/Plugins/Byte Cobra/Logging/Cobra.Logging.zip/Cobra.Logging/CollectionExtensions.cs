﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ByteCobra.Logging
{
    public static class CollectionExtensions
    {
        /// <summary>
        /// Converts a collection of objects into a comma-separated values (CSV) string.
        /// </summary>
        /// <param name="collection">The collection of objects to convert.</param>
        /// <returns>A CSV string representation of the collection.</returns>
        public static string ToCsv(this IEnumerable<object> collection)
        {
            if (collection == null || !collection.Any())
                return string.Empty;

            var stringBuilder = new StringBuilder();
            foreach (var item in collection)
                stringBuilder.Append(item?.ToString() + ",");

            // Remove the last comma to clean up the final CSV string
            if (stringBuilder.Length > 0)
                stringBuilder.Remove(stringBuilder.Length - 1, 1);

            return stringBuilder.ToString();
        }

        /// <summary>
        /// Converts a collection of objects into a CSV file.
        /// </summary>
        /// <param name="collection">The collection of objects to convert.</param>
        /// <param name="path">The file path where the CSV will be saved.</param>
        public static void ToCsvFile(this IEnumerable<object> collection, string path)
        {
            var csvContent = ToCsv(collection);

            // Ensure the directory exists
            var directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            // Write the CSV content to file
            File.WriteAllText(path, csvContent);
        }

        /// <summary>
        /// Converts a collection of objects into a JSON string using Newtonsoft.Json.
        /// </summary>
        /// <param name="collection">The collection of objects to convert.</param>
        /// <returns>A JSON string representation of the collection.</returns>
        public static string ToJson(this IEnumerable<object> collection)
        {
            return JsonConvert.SerializeObject(collection, Formatting.Indented);
        }

        /// <summary>
        /// Converts a collection of objects into a JSON file.
        /// </summary>
        /// <param name="collection">The collection of objects to convert.</param>
        /// <param name="path">The file path where the JSON will be saved.</param>
        public static void ToJsonFile(this IEnumerable<object> collection, string path)
        {
            var json = collection.ToJson();

            // Ensure the directory exists
            var directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            File.WriteAllText(path, json);
        }
    }
}