﻿using System.Collections.Generic;
using System.Linq;

namespace ByteCobra.Logging.Filters
{
    /// <summary>
    /// Represents a filter that filters log entries based on the namespace of the log's originating method.
    /// </summary>
    public class NamespaceFilter : Filter
    {
        /// <summary>
        /// Gets or sets the dictionary of namespaces and their corresponding minimum log levels.
        /// </summary>
        public Dictionary<string, LogLevel> NamespaceLevels { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="NamespaceFilter"/> class with the specified filter type and namespaces.
        /// </summary>
        /// <param name="filterType">The filter type to be applied.</param>
        /// <param name="namespaces">The dictionary of namespaces and their corresponding minimum log levels.</param>
        public NamespaceFilter(Dictionary<string, LogLevel> namespaces, FilterType filterType = FilterType.And)
            : base(filterType)
        {
            NamespaceLevels = namespaces;
        }

        public NamespaceFilter(FilterType filterType = FilterType.And) : base(filterType)
        {
            NamespaceLevels = new Dictionary<string, LogLevel>();
        }

        /// <summary>
        /// Validates whether a log entry should be included based on the namespace of the method that generated the log.
        /// </summary>
        /// <param name="log">The log entry to be validated.</param>
        /// <returns><c>true</c> if the log entry is valid based on namespace filtering; otherwise, <c>false</c>.</returns>
        public override bool Validate(BaseLog log)
        {
            if (log.StackTrace == null)
            {
                return true;
            }

            string? logNamespace = null;

            foreach (var frame in log.StackTrace.GetFrames())
            {
                var method = frame.GetMethod();
                if (method != null)
                {
                    logNamespace = method.DeclaringType?.Namespace;
                    if (!string.IsNullOrEmpty(logNamespace))
                    {
                        break;
                    }
                }
            }

            if (logNamespace == null)
            {
                return true;
            }

            // Find the closest matching namespace from the dictionary
            var matchingNamespace = NamespaceLevels
                .Where(ns => logNamespace.StartsWith(ns.Key))
                .OrderByDescending(ns => ns.Key.Length)
                .FirstOrDefault();

            if (matchingNamespace.Key != null)
            {
                return log.LogLevel >= matchingNamespace.Value;
            }

            return true;
        }
    }
}