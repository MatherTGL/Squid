﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ByteCobra.Logging.Filters
{
    /// <summary>
    /// Represents a filter that filters log entries based on the directory path of the log file.
    /// </summary>
    public class DirectoryFilter : Filter
    {
        /// <summary>
        /// Gets or sets the dictionary of directory paths and their corresponding minimum log levels.
        /// </summary>
        public Dictionary<string, LogLevel> DirectoryLevels { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectoryFilter"/> class with the specified filter type and directories.
        /// </summary>
        /// <param name="filterType">The filter type to be applied.</param>
        /// <param name="directories">The dictionary of directory paths and their corresponding minimum log levels.</param>
        public DirectoryFilter(Dictionary<string, LogLevel> directories, FilterType filterType = FilterType.And)
            : base(filterType)
        {
            // Normalize directory paths to use forward slashes
            DirectoryLevels = directories.ToDictionary(
                kvp => kvp.Key.Replace("\\", "/"),
                kvp => kvp.Value
            );
        }

        public DirectoryFilter(FilterType filterType = FilterType.And) : base(filterType)
        {
            DirectoryLevels = new Dictionary<string, LogLevel>();
        }

        /// <summary>
        /// Validates whether a log entry should be included based on the directory path of the log file.
        /// </summary>
        /// <param name="log">The log entry to be validated.</param>
        /// <returns><c>true</c> if the log entry is valid based on directory filtering; otherwise, <c>false</c>.</returns>
        public override bool Validate(BaseLog log)
        {
            string logDirectory = Path.GetDirectoryName(log.FileName) ?? string.Empty;

            var matchingDirectory = DirectoryLevels
                .Where(dir => logDirectory.EndsWith(dir.Key.Replace("/", Path.DirectorySeparatorChar.ToString()), StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(dir => dir.Key.Length)
                .FirstOrDefault();

            if (matchingDirectory.Key != null)
            {
                return log.LogLevel >= matchingDirectory.Value;
            }

            return true;
        }
    }
}