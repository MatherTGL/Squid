﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ByteCobra.Logging.Filters
{
    /// <summary>
    /// A filter that validates log entries based on their original log messages.
    /// </summary>
    public class MessageFilter : Filter
    {
        /// <summary>
        /// Gets the set of log messages to match against.
        /// </summary>
        public HashSet<string> Messages { get; } = new HashSet<string>();

        /// <summary>
        /// Gets or sets a value indicating whether the filter should check for a substring match or an exact match.
        /// </summary>
        public bool UseContainsCheck { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="StringComparison"/> used for comparing log messages.
        /// </summary>
        public StringComparison StringComparison { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageFilter"/> class with the specified filter type and messages.
        /// </summary>
        /// <param name="filterType">The type of filter.</param>
        /// <param name="messages">The messages to match for filtering log entries.</param>
        public MessageFilter(IEnumerable<string> messages, StringComparison stringComparison = StringComparison.Ordinal, bool useContainsCheck = true, FilterType filterType = FilterType.And) : base(filterType)
        {
            Messages.UnionWith(messages);
            StringComparison = stringComparison;
            UseContainsCheck = useContainsCheck;
        }

        /// <summary>
        /// Validates a log entry based on its original message.
        /// </summary>
        /// <param name="log">The log entry to validate.</param>
        /// <returns><c>true</c> if the log is valid according to the filter; otherwise, <c>false</c>.</returns>
        public override bool Validate(BaseLog log)
        {
            if (log.OriginalMessage == null || !Messages.Any())
                return false;

            if (UseContainsCheck)
            {
                // Check if any of the messages exists as a substring within the log's original message
                return Messages.Any(message => log.OriginalMessage.ToString().IndexOf(message, StringComparison) >= 0);
            }
            else
            {
                // Check if the log's original message matches any of the Messages exactly
                return Messages.Any(message => log.OriginalMessage.ToString().Equals(message, StringComparison));
            }
        }
    }
}