﻿namespace ByteCobra.Logging
{
    public enum LogLevel
    {
        Fatal,
        Error,
        Assert,
        Warning,
        Info,
        Debug
    }
}