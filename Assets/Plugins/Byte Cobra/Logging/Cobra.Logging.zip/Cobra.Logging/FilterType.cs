﻿namespace ByteCobra.Logging
{
    /// <summary>
    /// Represents the type of logical operation used for combining filters.
    /// </summary>
    public enum FilterType
    {
        /// <summary>
        /// Represents the logical "AND" operation for combining filters.
        /// </summary>
        And,

        /// <summary>
        /// Represents the logical "OR" operation for combining filters.
        /// </summary>
        Or
    }
}