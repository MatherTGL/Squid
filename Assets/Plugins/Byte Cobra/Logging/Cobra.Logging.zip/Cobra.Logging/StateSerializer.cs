﻿namespace ByteCobra.Logging
{
    /// <summary>
    /// Represents an abstract base class for state serializers used to serialize and save log object states.
    /// </summary>
    public abstract class StateSerializer
    {
        /// <summary>
        /// Serializes and saves the state of a log object.
        /// </summary>
        /// <param name="log">The log object whose state needs to be serialized.</param>
        public abstract void Serialize(BaseLog log);
    }
}