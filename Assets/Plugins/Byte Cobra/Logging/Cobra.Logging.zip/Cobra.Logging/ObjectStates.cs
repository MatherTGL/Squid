﻿using System;
using System.Diagnostics;
using System.Text;

namespace ByteCobra.Logging
{
    /// <summary>
    /// Represents the state of an object captured during logging.
    /// </summary>
    public class ObjectState
    {
        /// <summary>
        /// Gets the timestamp when the state was captured.
        /// </summary>
        public DateTime TimeStamp { get; }

        /// <summary>
        /// Gets or sets an optional message associated with the state.
        /// </summary>
        public string? Message { get; set; }

        /// <summary>
        /// Gets the captured object's state.
        /// </summary>
        public object State { get; }

        /// <summary>
        /// Gets or sets the formatted stack trace associated with the state.
        /// </summary>
        public string? StackTrace { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectState"/> class with the specified object's state and optional stack trace.
        /// </summary>
        /// <param name="states">The captured object's state.</param>
        /// <param name="stackTrace">An optional stack trace associated with the state.</param>
        public ObjectState(object states, StackTrace? stackTrace = null)
        {
            TimeStamp = DateTime.Now;
            State = states;
            StackTrace = stackTrace != null ? FormatStackTrace(stackTrace) : default;
        }

        private static string? FormatStackTrace(StackTrace? stackTrace)
        {
            if (stackTrace == null)
                return null;

            StringBuilder formattedStackTrace = new StringBuilder();

            // Get the frames from the stack trace
            StackFrame[] frames = stackTrace.GetFrames();

            // Return null if there are no frames
            if (frames == null || frames.Length == 0) return null;

            // Iterate through the frames in standard order
            for (int i = 0; i < frames.Length; i++)
            {
                StackFrame frame = frames[i];

                // Get the method from the frame
                var method = frame.GetMethod();

                if (method == null) continue;

                formattedStackTrace.Append($"{method.DeclaringType}.{method.Name}");

                // If you want file names (without path) and line numbers (when they're available):
                if (frame.GetFileName() != null)
                {
                    formattedStackTrace.Append($"[{frame.GetFileLineNumber()}]");
                }

                // Separate each frame's details with a comma and a space
                if (i < frames.Length - 1)
                {
                    formattedStackTrace.Append(", ");
                }
            }

            return formattedStackTrace.Length > 0 ? formattedStackTrace.ToString() : null;
        }
    }
}