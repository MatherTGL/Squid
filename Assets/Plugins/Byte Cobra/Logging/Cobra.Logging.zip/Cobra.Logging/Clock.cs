﻿using System;
using System.Collections.Concurrent;

namespace ByteCobra.Logging
{
    public static class Clock
    {
        private static readonly ConcurrentDictionary<string, DateTime> timers = new ConcurrentDictionary<string, DateTime>();
        private static string DefaultKey => string.Empty;

        /// <summary>
        /// Starts or restarts a timer. If the key is null, a default timer is used.
        /// </summary>
        /// <param name="key">The key to identify the timer, or null to use the default timer.</param>
        public static void Start(string key = "")
        {
            key = key ?? DefaultKey;
            timers[key] = DateTime.UtcNow;
        }

        /// <summary>
        /// Stops the timer and returns the elapsed time. Logs the elapsed time or an error if the timer was not started.
        /// If the key is null or empty, the default timer is stopped. Optionally logs the result.
        /// </summary>
        /// <param name="key">The key to identify the timer, or null/empty for the default timer.</param>
        /// <param name="log">Whether to log the stopping of the timer.</param>
        /// <returns>The TimeSpan representing the elapsed time since the timer was started.</returns>
        public static TimeSpan Stop(string key = "", bool log = true)
        {
            key = key ?? DefaultKey;
            string messageKey = string.IsNullOrEmpty(key) ? "Process" : $"Timer '{key}'";

            if (timers.TryRemove(key, out var startTime))
            {
                var elapsedTime = DateTime.UtcNow - startTime;
                var elapsedTimeFormatted = $"{elapsedTime}";

                if (log)
                    Log.Info($"{messageKey} took {elapsedTimeFormatted}");

                return elapsedTime;
            }
            else
            {
                if (log)
                    Log.Error($"{messageKey} was not started.", throwException: false);

                return TimeSpan.Zero;
            }
        }
    }
}