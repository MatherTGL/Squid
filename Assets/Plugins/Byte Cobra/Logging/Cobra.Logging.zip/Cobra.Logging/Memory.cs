﻿using System;

namespace ByteCobra.Logging
{
    public static class Memory
    {
        /// <summary>
        /// Logs the current memory usage of the application.
        /// </summary>
        /// <param name="log">Whether to log the memory usage to the console.</param>
        /// <returns>The current memory usage in megabytes.</returns>
        public static double Measure(bool log = true)
        {
            // Get the total memory used by the managed code, in bytes.
            long totalMemory = GC.GetTotalMemory(false);

            // Convert bytes to megabytes for easier understanding.
            double memoryInMB = totalMemory / 1024.0 / 1024.0;

            if (log)
                Log.Info($"Current memory usage: {memoryInMB:N2} MB");

            return memoryInMB;
        }

        /// <summary>
        /// Forces an immediate garbage collection of all generations, waits for finalizers of objects that are ready to finalize,
        /// and then forces another garbage collection to reclaim the memory of objects that were just finalized.
        /// </summary>
        /// <remarks>
        /// This method triggers two full garbage collection cycles with a wait for pending finalizers in between.
        /// Use this method judiciously as forcing garbage collection can affect application performance.
        /// It's generally recommended to rely on the automatic garbage collection process unless there's a specific need
        /// for immediate release of memory resources.
        /// </remarks>
        public static void Collect()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
    }
}