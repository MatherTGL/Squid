﻿using ByteCobra.Logging.Settings;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.IO;
using System.Linq;
using System.Text;

namespace ByteCobra.Logging
{
    /// <summary>
    /// Represents a JSON serializer for log object states.
    /// </summary>
    public class JsonStateSerializer : StateSerializer
    {
        private readonly JsonSerializerSettings settings;

        /// <summary>
        /// Initializes a new instance of the <see cref="JsonStateSerializer"/> class.
        /// </summary>
        public JsonStateSerializer()
        {
            settings = new JsonSerializerSettings
            {
                ContractResolver = new DefaultContractResolver
                {
                    DefaultMembersSearchFlags = System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance
                },

                ObjectCreationHandling = ObjectCreationHandling.Replace, // Handles non-default constructors
                Formatting = Formatting.Indented, // For pretty-printed JSON
            };
        }

        /// <summary>
        /// Sanitizes a given file name by removing invalid characters.
        /// </summary>
        /// <param name="fileName">The original file name to be sanitized.</param>
        /// <returns>The sanitized file name.</returns>
        public static string SanitizeFileName(string fileName)
        {
            var invalidChars = Path.GetInvalidFileNameChars();
            StringBuilder sanitized = new StringBuilder();

            foreach (var ch in fileName)
            {
                if (!Array.Exists(invalidChars, invalidChar => invalidChar == ch))
                {
                    sanitized.Append(ch);
                }
            }

            return sanitized.ToString();
        }

        /// <summary>
        /// Gets the file name for serializing the state of the given log.
        /// </summary>
        /// <param name="log">The log for which the state is being serialized.</param>
        /// <returns>The file name for the serialized state.</returns>
        protected virtual string GetFileName(BaseLog log)
        {
            return $"{log.FileName}[{log.Line}].json";
        }

        /// <summary>
        /// Serializes the state of the given log and saves it to a file.
        /// </summary>
        /// <param name="log">The log for which the state is being serialized.</param>
        public override void Serialize(BaseLog log)
        {
            try
            {
                string json = JsonConvert.SerializeObject(log.State, settings);

                if (!LogSettings.FileSettings.StatesDirectory.Exists)
                    LogSettings.FileSettings.StatesDirectory.Create();

                string fileName = SanitizeFileName(GetFileName(log));
                string fullPath = Path.Combine(LogSettings.FileSettings.StatesDirectory.FullName, fileName);

                long maxStateDirectorySize = LogSettings.FileSettings.MaxStateDirectorySize;

                File.WriteAllText(fullPath, json);

                // Check if directory size is greater than max size
                if (GetDirectorySize(LogSettings.FileSettings.StatesDirectory) > maxStateDirectorySize)
                {
                    ClearJsonFilesFromDirectory(LogSettings.FileSettings.StatesDirectory);
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to serialize and save state due to exception {ex.Message}", ex);
            }
        }

        private long GetDirectorySize(DirectoryInfo directory)
        {
            return directory.GetFiles().Sum(file => file.Length);
        }

        private void ClearJsonFilesFromDirectory(DirectoryInfo directory)
        {
            foreach (var file in directory.GetFiles("*.json"))
            {
                file.Delete();
            }
        }
    }
}