﻿namespace ByteCobra.Logging
{
    /// <summary>
    /// Represents a base class for log filters.
    /// </summary>
    public abstract class Filter
    {
        /// <summary>
        /// Gets the type of filter.
        /// </summary>
        public FilterType FilterType { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Filter"/> class with the specified filter type.
        /// </summary>
        /// <param name="filterType">The type of filter.</param>
        public Filter(FilterType filterType)
        {
            FilterType = filterType;
        }

        /// <summary>
        /// Validates whether a log message passes the filter conditions.
        /// </summary>
        /// <param name="log">The log message to be validated.</param>
        /// <returns><c>true</c> if the log message passes the filter conditions, otherwise <c>false</c>.</returns>
        public abstract bool Validate(BaseLog log);
    }
}