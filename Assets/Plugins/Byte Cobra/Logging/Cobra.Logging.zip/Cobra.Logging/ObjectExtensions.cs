﻿using Newtonsoft.Json;
using System.IO;

namespace ByteCobra.Logging
{
    public static class ObjectExtensions
    {
        /// <summary>
        /// Converts an object into a JSON string using Newtonsoft.Json, with pretty print formatting.
        /// </summary>
        /// <param name="obj">The object to convert.</param>
        /// <returns>A pretty-printed JSON string representation of the object.</returns>
        public static string ToJson(this object obj)
        {
            return JsonConvert.SerializeObject(obj, Formatting.Indented);
        }

        /// <summary>
        /// Converts an object into a JSON file.
        /// </summary>
        /// <param name="obj">The object to convert.</param>
        /// <param name="path">The file path where the JSON will be saved.</param>
        public static void ToJsonFile(this object obj, string path)
        {
            var json = obj.ToJson();

            // Ensure the directory exists
            var directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            File.WriteAllText(path, json);
        }
    }
}