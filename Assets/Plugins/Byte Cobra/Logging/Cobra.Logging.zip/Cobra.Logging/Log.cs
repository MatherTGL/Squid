﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using ByteCobra.Logging.Logs;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging
{
    /// <summary>
    /// Provides methods for creating and logging various types of log messages.
    /// </summary>
    /// <remarks>
    /// The <see cref="Log"/> class serves as a central point for creating and recording log messages
    /// of different severity levels, such as informational, debug, warning, error, and assert logs.
    /// It utilizes the configuration settings from <see cref="LogSettings"/> to determine whether
    /// specific types of logs are enabled and to customize their behavior. The class also allows the
    /// option to capture stack traces and associate state information with log messages.
    /// </remarks>
    public class Log
    {
        /// <summary>
        /// Event triggered when a new log entry is created.
        /// Listeners can subscribe to this event to receive log notifications.
        /// </summary>
        public static event Action<BaseLog> OnLog;

        private static readonly object logLock = new object();

        /// <summary>
        /// Captures a stack trace.
        /// </summary>
        /// <param name="skipFrames">Number of frames to skip in the stack trace.</param>
        /// <returns>A <see cref="StackTrace"/> instance.</returns>
        protected static StackTrace CaptureStackTrace(ushort skipFrames = 2)
        {
            return new StackTrace(skipFrames, true);
        }

        public static void DeleteLogFiles()
        {
            lock (logLock)
            {
                DeleteFilesFromDirectory(LogSettings.FileSettings.LogFilesDirectory);
                DeleteFilesFromDirectory(LogSettings.FileSettings.StatesDirectory);
            }
        }

        private static void DeleteFilesFromDirectory(DirectoryInfo directory)
        {
            if (directory.Exists)
            {
                foreach (var file in directory.GetFiles())
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception ex)
                    {
                        Error($"Could not delete {file.FullName}. {ex.Message}\n{ex.StackTrace}", throwException: false);
                    }
                }
            }
        }

        /// <summary>
        /// Validates whether a log message passes the filter conditions.
        /// </summary>
        /// <param name="log">The log message to be validated.</param>
        /// <returns><c>true</c> if the log message passes the filter conditions, otherwise <c>false</c>.</returns>
        protected static bool Validate(BaseLog log)
        {
            bool? lastResult = null;

            foreach (var filter in LogSettings.Filters)
            {
                bool result = filter.Validate(log);
                if (filter.FilterType == FilterType.Or && result)
                {
                    return true;
                }
                else if (filter.FilterType == FilterType.And && !result)
                {
                    return false;
                }

                lastResult = result;
            }

            // If there were no filters, default to valid
            return lastResult ?? true;
        }

        private static void WriteStateToFile(BaseLog log)
        {
            if (log.State != null && log.State.State != null)
                LogSettings.StateSerializer.Serialize(log);
        }

        private static void WriteLogToFile(BaseLog log)
        {
            long maxFileSize = LogSettings.FileSettings.MaxFileSize;
            FileInfo file = new FileInfo(Path.Combine(LogSettings.FileSettings.LogFilesDirectory.FullName, LogSettings.FileSettings.FileName));

            // Ensure the directory exists before writing to the file
            if (!file.Directory.Exists)
                file.Directory.Create();

            lock (logLock)
            {
                // Double check for file size inside the lock
                if (file.Exists && file.Length > maxFileSize)
                    File.WriteAllText(file.FullName, string.Empty);

                using (StreamWriter writer = new StreamWriter(file.FullName, true))  // true for append mode
                {
                    writer.WriteLine(log.FormattedMessage);
                }
            }
        }

        /// <summary>
        /// Creates and logs an informational message.
        /// </summary>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <returns>An <see cref="InfoLog"/> representing the recorded log.</returns>
        /// <remarks>
        /// This method is used to create and log an informational message. If info logs are enabled,
        /// the provided message will be recorded along with additional contextual information.
        /// </remarks>
        public static InfoLog? Info(object message, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            if ((int)LogSettings.MinimumLogLevel < (int)LogLevel.Info)
                return null;

            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            InfoLog result = new InfoLog(stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return default;

            LogSettings.PrintSettings.PrintInfo(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            return result;
        }

        private static void Write(BaseLog log)
        {
            if (LogSettings.FileSettings.SaveLogs)
                WriteLogToFile(log);

            if (LogSettings.FileSettings.SaveStates)
                WriteStateToFile(log);
        }

        /// <summary>
        /// Creates and logs a debug message.
        /// </summary>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <returns>A <see cref="DebugLog"/> representing the recorded log.</returns>
        /// <remarks>
        /// This method is used to create and log a debug message. If debug logs are enabled,
        /// the provided message will be recorded along with additional contextual information.
        /// </remarks>
        public static DebugLog? Debug(object message, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            if ((int)LogSettings.MinimumLogLevel < (int)LogLevel.Debug)
                return null;

            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            DebugLog result = new DebugLog(stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return default;

            LogSettings.PrintSettings.PrintDebug(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            return result;
        }

        /// <summary>
        /// Creates and logs a warning message.
        /// </summary>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <returns>A <see cref="WarningLog"/> representing the recorded log.</returns>
        /// <remarks>
        /// This method is used to create and log a warning message. If warnings are enabled,
        /// the provided message will be recorded along with additional contextual information.
        /// </remarks>
        public static WarningLog? Warning(object message, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            if ((int)LogSettings.MinimumLogLevel < (int)LogLevel.Warning)
                return null;

            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            WarningLog result = new WarningLog(stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return default;

            LogSettings.PrintSettings.PrintWarning(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            return result;
        }

        /// <summary>
        /// Creates and logs an assert message.
        /// </summary>
        /// <param name="condition">The condition to assert.</param>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="throwException">Whether to throw an exception on assertion failure.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <returns>An <see cref="AssertLog"/> representing the recorded log.</returns>
        /// <remarks>
        /// This method is used to create and log an assert message. If asserts are enabled,
        /// the provided condition will be checked, and if it evaluates to false, an assert log
        /// will be recorded along with additional contextual information. If <paramref name="throwException"/>
        /// is set to true and the condition fails, an exception will be thrown after logging the assert message.
        /// </remarks>
        public static AssertLog? Assert(bool condition, object? message = null, bool throwException = true, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            if ((int)LogSettings.MinimumLogLevel < (int)LogLevel.Assert)
                return null;

            if (condition)
                return null;

            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            AssertLog result = new AssertLog(throwException, stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return default;

            LogSettings.PrintSettings.PrintAssert(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            if (throwException)
                throw new System.Exception(result.FormattedMessage);

            return result;
        }

        /// <summary>
        /// Creates and logs an error message.
        /// </summary>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="throwException">Whether to throw an exception on error.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <returns>An <see cref="ErrorLog"/> representing the recorded log.</returns>
        /// <remarks>
        /// This method is used to create and log an error message. If error logs are enabled,
        /// the provided message will be recorded along with additional contextual information.
        /// If <paramref name="throwException"/> is set to true, an exception may be thrown
        /// after logging the error message, depending on the configured behavior.
        /// </remarks>
        public static ErrorLog? Error(object message, bool throwException = true, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            if ((int)LogSettings.MinimumLogLevel < (int)LogLevel.Error)
                return null;

            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            ErrorLog result = new ErrorLog(throwException, stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return default;

            LogSettings.PrintSettings.PrintError(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            if (throwException)
                throw new System.Exception(result.FormattedMessage);

            return result;
        }

        /// <summary>
        /// Creates and logs a fatal message.
        /// </summary>
        /// <param name="message">The log message to be recorded.</param>
        /// <param name="file">The file path of the caller.</param>
        /// <param name="line">The line number of the caller.</param>
        /// <param name="quit">Whether to quit the application after logging.</param>
        /// <param name="state">An optional state object associated with the log.</param>
        /// <remarks>
        /// This method is used to create and log a fatal message. If fatal logs are enabled,
        /// the provided message will be recorded along with additional contextual information.
        /// If <paramref name="quit"/> is set to true, the application may exit after logging
        /// the fatal message, depending on the configured behavior.
        /// </remarks>
        public static void Fatal(object message, bool quit = false, [CallerFilePath] string file = "", [CallerLineNumber] int line = -1, object? state = null)
        {
            StackTrace? stackTrace = null;
            if (LogSettings.CaptureStackTrace)
                stackTrace = CaptureStackTrace();

            ObjectState? objectStates = state != null ? new ObjectState(state, stackTrace) : null;
            FatalLog result = new FatalLog(quit, stackTrace, file, line, message, objectStates);

            if (!Validate(result))
                return;

            LogSettings.PrintSettings.PrintError(result.FormattedMessage);

            Write(result);

            OnLog?.Invoke(result);

            if (quit)
                LogSettings.QuitAction();

            throw new System.Exception(result.FormattedMessage);
        }
    }
}