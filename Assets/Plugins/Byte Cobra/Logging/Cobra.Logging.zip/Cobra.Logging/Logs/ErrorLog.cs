﻿using System;
using System.Diagnostics;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging.Logs
{
    /// <summary>
    /// Represents a log entry for error messages.
    /// </summary>
    public class ErrorLog : BaseLog
    {
        /// <summary>
        /// Gets the tag associated with error logs.
        /// </summary>
        public override string Tag => LogSettings.TagSettings.ErrorTag;

        /// <summary>
        /// Gets a value indicating whether an exception should be thrown for the error.
        /// </summary>
        public bool ThrowException { get; }

        /// <summary>
        /// Gets the type of the log entry.
        /// </summary>
        public override Type Type => typeof(ErrorLog);

        /// <summary>
        /// Gets the color associated with the error log.
        /// </summary>
        public override string Color => LogSettings.ColorSettings.ErrorLogColor;

        /// <summary>
        /// Gets the formatted message for the error log.
        /// </summary>
        public override string FormattedMessage => LogSettings.FormatSettings.ErrorFormat(this);

        /// <summary>
        /// The log level.
        /// </summary>
        public override LogLevel LogLevel => LogLevel.Error;

        /// <summary>
        /// Initializes a new instance of the <see cref="ErrorLog"/> class.
        /// </summary>
        /// <param name="throwException">A value indicating whether to throw an exception for the error.</param>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="fileName">The name of the source file.</param>
        /// <param name="lineNumber">The line number in the source file.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The object state associated with the log.</param>
        public ErrorLog(bool throwException, StackTrace? stackTrace, string fileName, int lineNumber, object message, ObjectState? objectState)
            : base(stackTrace, fileName, lineNumber, message, objectState)
        {
            ThrowException = throwException;
        }
    }
}