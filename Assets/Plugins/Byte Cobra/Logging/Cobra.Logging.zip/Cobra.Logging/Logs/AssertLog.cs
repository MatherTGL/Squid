﻿using System;
using System.Diagnostics;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging.Logs
{
    /// <summary>
    /// Represents a log entry for assertions.
    /// </summary>
    public class AssertLog : BaseLog
    {
        /// <summary>
        /// Gets the tag associated with the assertion logs.
        /// </summary>
        public override string Tag => LogSettings.TagSettings.AssertTag;

        /// <summary>
        /// Gets a value indicating whether an exception should be thrown for this assertion log.
        /// </summary>
        public bool ThrowException { get; }

        /// <summary>
        /// Gets the type of the log entry.
        /// </summary>
        public override Type Type => typeof(AssertLog);

        /// <summary>
        /// Gets the color associated with the assertion log.
        /// </summary>
        public override string Color => LogSettings.ColorSettings.AssertLogColor;

        /// <summary>
        /// Gets the formatted message for the assertion log.
        /// </summary>
        public override string FormattedMessage => LogSettings.FormatSettings.AssertFormat(this);

        /// <summary>
        /// The log level.
        /// </summary>
        public override LogLevel LogLevel => LogLevel.Assert;

        /// <summary>
        /// Initializes a new instance of the <see cref="AssertLog"/> class.
        /// </summary>
        /// <param name="throwException">A value indicating whether an exception should be thrown for this assertion log.</param>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="fileName">The name of the source file.</param>
        /// <param name="lineNumber">The line number in the source file.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The object state associated with the log.</param>
        public AssertLog(bool throwException, StackTrace? stackTrace, string fileName, int lineNumber, object? message, ObjectState? objectState)
            : base(stackTrace, fileName, lineNumber, message, objectState)
        {
            ThrowException = throwException;
        }
    }
}