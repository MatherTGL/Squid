﻿using System;
using System.Diagnostics;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging.Logs
{
    /// <summary>
    /// Represents a log entry for fatal messages.
    /// </summary>
    public class FatalLog : BaseLog
    {
        /// <summary>
        /// Gets the tag associated with fatal logs.
        /// </summary>
        public override string Tag => LogSettings.TagSettings.FatalTag;

        /// <summary>
        /// Gets a value indicating whether the application should quit due to the fatal error.
        /// </summary>
        public bool Quit { get; }

        /// <summary>
        /// Gets the type of the log entry.
        /// </summary>
        public override Type Type => typeof(FatalLog);

        /// <summary>
        /// Gets the color associated with the fatal log.
        /// </summary>
        public override string Color => LogSettings.ColorSettings.FatalLogColor;

        /// <summary>
        /// Gets the formatted message for the fatal log.
        /// </summary>
        public override string FormattedMessage => LogSettings.FormatSettings.FatalFormat(this);

        /// <summary>
        /// The log level.
        /// </summary>
        public override LogLevel LogLevel => LogLevel.Fatal;

        /// <summary>
        /// Initializes a new instance of the <see cref="FatalLog"/> class.
        /// </summary>
        /// <param name="quit">A value indicating whether the application should quit due to the fatal error.</param>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="fileName">The name of the source file.</param>
        /// <param name="lineNumber">The line number in the source file.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The object state associated with the log.</param>
        public FatalLog(bool quit, StackTrace? stackTrace, string fileName, int lineNumber, object message, ObjectState? objectState)
            : base(stackTrace, fileName, lineNumber, message, objectState)
        {
            Quit = quit;
        }
    }
}