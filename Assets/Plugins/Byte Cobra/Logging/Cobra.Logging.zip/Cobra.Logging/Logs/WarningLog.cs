﻿using System;
using System.Diagnostics;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging.Logs
{
    /// <summary>
    /// Represents a log entry for warning messages.
    /// </summary>
    public class WarningLog : BaseLog
    {
        /// <summary>
        /// Gets the tag associated with warning logs.
        /// </summary>
        public override string Tag => LogSettings.TagSettings.WarningTag;

        /// <summary>
        /// Gets the type of the log entry.
        /// </summary>
        public override Type Type => typeof(WarningLog);

        /// <summary>
        /// Gets the color associated with the warning log.
        /// </summary>
        public override string Color => LogSettings.ColorSettings.WarningLogColor;

        /// <summary>
        /// Gets the formatted message for the warning log.
        /// </summary>
        public override string FormattedMessage => LogSettings.FormatSettings.WarningFormat(this);

        /// <summary>
        /// The log level.
        /// </summary>
        public override LogLevel LogLevel => LogLevel.Warning;

        /// <summary>
        /// Initializes a new instance of the <see cref="WarningLog"/> class.
        /// </summary>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="fileName">The name of the source file.</param>
        /// <param name="lineNumber">The line number in the source file.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The object state associated with the log.</param>
        public WarningLog(StackTrace? stackTrace, string fileName, int lineNumber, object message, ObjectState? objectState)
            : base(stackTrace, fileName, lineNumber, message, objectState)
        {
        }
    }
}