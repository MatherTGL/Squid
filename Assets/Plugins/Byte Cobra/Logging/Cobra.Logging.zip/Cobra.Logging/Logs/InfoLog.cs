﻿using System;
using System.Diagnostics;
using ByteCobra.Logging.Settings;

namespace ByteCobra.Logging.Logs
{
    /// <summary>
    /// Represents a log entry for informational messages.
    /// </summary>
    public class InfoLog : BaseLog
    {
        /// <summary>
        /// Gets the tag associated with informational logs.
        /// </summary>
        public override string Tag => LogSettings.TagSettings.InfoTag;

        /// <summary>
        /// Gets the type of the log entry.
        /// </summary>
        public override Type Type => typeof(InfoLog);

        /// <summary>
        /// Gets the color associated with the informational log.
        /// </summary>
        public override string Color => LogSettings.ColorSettings.InfoLogColor;

        /// <summary>
        /// Gets the formatted message for the informational log.
        /// </summary>
        public override string FormattedMessage => LogSettings.FormatSettings.InfoFormat(this);

        /// <summary>
        /// The log level.
        /// </summary>
        public override LogLevel LogLevel => LogLevel.Info;

        /// <summary>
        /// Initializes a new instance of the <see cref="InfoLog"/> class.
        /// </summary>
        /// <param name="stackTrace">The stack trace associated with the log.</param>
        /// <param name="fileName">The name of the source file.</param>
        /// <param name="lineNumber">The line number in the source file.</param>
        /// <param name="message">The log message.</param>
        /// <param name="objectState">The object state associated with the log.</param>
        public InfoLog(StackTrace? stackTrace, string fileName, int lineNumber, object message, ObjectState? objectState)
            : base(stackTrace, fileName, lineNumber, message, objectState)
        {
        }
    }
}